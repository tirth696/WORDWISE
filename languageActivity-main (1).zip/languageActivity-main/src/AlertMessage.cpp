using namespace std;

void AlertMessage(int rows, int columns, string type, string msg)
{
    int boxWidth = msg.length() + 8; 
    int boxHeight = 3, key;          
     if (type == "Success")
    {
        cout << Color_Green;
    }
    else if (type == "Error")
    {
        cout << Color_Red;
    }
    else if (type == "Warning")
    {
        cout << Color_Yellow;
    }
    else
    {
        cout << Color_White; 
    }
    
    moveCursorToPosition(columns - (boxWidth / 2), rows);
    cout << "* " << string(boxWidth - 4, '-') << " *";

    
    moveCursorToPosition(columns - (boxWidth / 2), rows + 1);
    cout << "|   " << msg << "   |";

    
    moveCursorToPosition(columns - (boxWidth / 2), rows + 2);
    cout << "* " << string(boxWidth - 4, '-') << " *";
    cout << Color_Reset;
    while (true)
    {
        key = _getch();
        if (key == 13)
        {
            clearLines(rows, rows + 3);
            break;
        }
    }
}