#include <string>
using namespace std;

string Color_Black = "\033[30m";
string Color_Red = "\033[31m";
string Color_Green = "\033[32m";
string Color_Yellow = "\033[33m";
string Color_Blue = "\033[34m";
string Color_Magenta = "\033[35m";
string Color_Cyan = "\033[36m";
string Color_White = "\033[37m";
string Color_Reset = "\033[0m";
 
string Color_Bright_Black = "\033[90m";
string Color_Bright_Red = "\033[91m";
string Color_Bright_Green = "\033[92m";
string Color_Bright_Yellow = "\033[93m";
string Color_Bright_Blue = "\033[94m";
string Color_Bright_Magenta = "\033[95m";
string Color_Bright_Cyan = "\033[96m";
string Color_Bright_White = "\033[97m";
string Color_Bright_Default = "\033[99m";
 
string Color_Background_Black = "\033[40m";
string Color_Background_Red = "\033[41m";
string Color_Background_Green = "\033[42m";
string Color_Background_Yellow = "\033[43m";
string Color_Background_Blue = "\033[44m";
string Color_Background_Magenta = "\033[45m";
string Color_Background_Cyan = "\033[46m";
string Color_Background_White = "\033[47m";
string Color_Background_Default = "\033[49m";
 
string Color_Bright_Background_Black = "\033[100m";
string Color_Bright_Background_Red = "\033[101m";
string Color_Bright_Background_Green = "\033[102m";
string Color_Bright_Background_Yellow = "\033[103m";
string Color_Bright_Background_Blue = "\033[104m";
string Color_Bright_Background_Magenta = "\033[105m";
string Color_Bright_Background_Cyan = "\033[106m";
string Color_Bright_Background_White = "\033[107m";
string Color_Bright_Background_Default = "\033[109m";
 
 
 
// for Color_Text Effect   =====================================
 
string Color_Bold_On = "\033[1m";
string Color_Bold_Off = "\033[21m";
 
string Color_Dim_On = "\033[2m";
string Color_Dim_Off = "\033[22m";
 
string Color_Underline_On = "\033[4m";
string Color_Underline_Off = "\033[24m";
 
string Color_Blink_On = "\033[5m";
string Color_Blink_Off = "\033[25m";
 
string Color_Reverse_On = "\033[7m";
string Color_Reverse_Off = "\033[27m";
 
string Color_Hide_On = "\033[8m";
string Color_Hide_Off = "\033[28m";